const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
app.use(cors());

const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: "*",
  }
});

// Liste des utilisateurs connectés
let users = [];

io.on('connection', (socket) => {
  console.log('New user connected:', socket.id);

  // Quand un utilisateur arrive
  socket.on("user_connected", (user) => {
    const newUser = {
      id: socket.id,
      username: user.username,
      avatar: user.avatar
    };

    users.push(newUser);
    console.log("Users connected:", users);

    // Envoi à tout le monde
    io.emit("update_users", users);
  });

  // Rejoindre un channel
  socket.on('join_channel', (channel) => {
    socket.join(channel);
    console.log(`User ${socket.id} joined channel ${channel}`);
  });

  // Message d’un channel
  socket.on('send_message', ({ channel, message }) => {
    io.to(channel).emit('receive_message', { channel, message });
  });

  // Déconnexion
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);

    // Retirer de la liste d’utilisateurs
    users = users.filter(u => u.id !== socket.id);

    // Mise à jour chez tous les clients
    io.emit("update_users", users);
  });
});

const PORT = 3001;
server.listen(PORT, () => console.log(`Server listening on port ${PORT}`));
