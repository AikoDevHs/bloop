import { useState, useEffect, useRef } from "react";
import { createClient } from "@supabase/supabase-js";
import "./App.css";

const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_ANON_KEY
);

const CHANNELS = ["général", "discussion", "projets"];

const avatars = [
  "https://cdn.discordapp.com/attachments/1440812096400003265/1440813838168752319/image.png?ex=69218034&is=69202eb4&hm=32a237b81d50e7660230fdf98561e96699d341b2cb0fd9f397b1b9c9c9d974e7&",
  "https://cdn.discordapp.com/attachments/1440812096400003265/1440814033879175178/image.png?ex=69218062&is=69202ee2&hm=73fef377d477ff12eb4187bd2a1f2f5a775c9021e646c2402f46dadaf4d055f2&",
  "https://media.discordapp.net/attachments/1440812096400003265/1440813139754090647/image.png?ex=69217f8d&is=69202e0d&hm=9a2fce6dd063fb556ade86ed0a1435395911cde3469653198022401b5e7ca3cc&=&format=webp&quality=lossless",
  "https://media.discordapp.net/attachments/1440812096400003265/1440812117132316775/image.png?ex=69217e99&is=69202d19&hm=2cb8f823f366d48a6354dafa21d219caa25225f6317588493e8a6665f7416d20&=&format=webp&quality=lossless",
  "https://cdn.discordapp.com/attachments/1440812096400003265/1440813371644706907/image.png?ex=69217fc4&is=69202e44&hm=4c1f619b41582cce17a98fe4fc6e6be238879c0ac46383dff844c19c5511cf21&",  
  "https://media.discordapp.net/attachments/1440812096400003265/1440813533024747662/image.png?ex=69217feb&is=69202e6b&hm=f3e4d21bb105d56073370ae345352348dde18332999d4b7a59fec0c05867eb96&=&format=webp&quality=lossless",
  "https://media.discordapp.net/attachments/1440812096400003265/1440814273419940041/image.png?ex=6921809b&is=69202f1b&hm=d3a30ddac8972920b381cff6905cab68ddb9a36af77dd083cfd21f50978606a0&=&format=webp&quality=lossless",
  "https://media.discordapp.net/attachments/1440812096400003265/1440814476600410303/image.png?ex=692180cc&is=69202f4c&hm=ad72c87788673cd4204739f29f561cd691dfd22c2dba29f4ab6d54119e406e60&=&format=webp&quality=lossless"
];

const randomAvatar = () => {
  const index = Math.floor(Math.random() * avatars.length);
  return avatars[index];
};

export default function App() {
  const [username] = useState("User" + Math.floor(Math.random() * 999));
  const [avatar] = useState(randomAvatar());

  const [currentChannel, setCurrentChannel] = useState("général");
  const [messages, setMessages] = useState<Record<string, any[]>>({
    général: [],
    discussion: [],
    projets: []
  });

  const [friends, setFriends] = useState<any[]>([]);
  const [input, setInput] = useState("");

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  useEffect(scrollToBottom, [messages[currentChannel]]);

  // -------------------------------
  // 🔥 1. PRESENCE
  // -------------------------------
  useEffect(() => {
    const presenceChannel = supabase.channel("presence", {
      config: {
        presence: { key: username }
      }
    });

    presenceChannel
      .on("presence", { event: "sync" }, () => {
        const state = presenceChannel.presenceState();
        const list = Object.values(state).map((v: any) => v[0]);
        setFriends(list);
      })
      .subscribe((status) => {
        if (status === "SUBSCRIBED") {
          presenceChannel.track({ username, avatar });
        }
      });

    return () => {
      supabase.removeChannel(presenceChannel);
    };
  }, []);

  // -------------------------------
  // 🔥 2. Charger les messages
  // -------------------------------
  useEffect(() => {
    const loadMessages = async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("channel", currentChannel)
        .order("created_at", { ascending: true });

      if (error) console.error("❌ SELECT error :", error);

      setMessages((prev) => ({
        ...prev,
        [currentChannel]: data || []
      }));
    };

    loadMessages();
  }, [currentChannel]);

  // -------------------------------
  // 🔥 3. Realtime
  // -------------------------------
  useEffect(() => {
    const channel = supabase
      .channel(`messages-${currentChannel}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `channel=eq.${currentChannel}`
        },
        (payload) => {
          setMessages((prev) => ({
            ...prev,
            [currentChannel]: [...prev[currentChannel], payload.new]
          }));
        }
      )
      .subscribe((status) => {
        console.log("Realtime:", status);
      });

    return () => supabase.removeChannel(channel);
  }, [currentChannel]);

  // -------------------------------
  // 🔥 4. Envoyer un message
  // -------------------------------
  const sendMessage = async () => {
    if (!input.trim()) return;

    const text = input;
    setInput("");

    const { error } = await supabase.from("messages").insert({
      channel: currentChannel,
      username,
      avatar,
      text
    });

    if (error) {
      console.error("❌ Erreur Supabase :", error);
      alert("Erreur : " + error.message);
    }
  };

  return (
    <div className="discord-app">
          <div className="background"></div>

      {/* GAUCHE */}
<div className="sidebar">
  {/* Logo du serveur */}
  <div className="server-logo">
    <img className="logo" src="/logo.png" alt="Logo" />
  </div>

  {/* Liste des channels */}
  <ul>
    {CHANNELS.map((ch) => (
      <li
        key={ch}
        onClick={() => setCurrentChannel(ch)}
        style={{
          background: currentChannel === ch ? "#00d9ff" : "transparent",
          borderRadius: "5px",
          padding: "5px"
        }}
      >
        # {ch}
      </li>
    ))}
  </ul>
</div>


      {/* MESSAGES */}
      <div className="chat-area">
        <div className="messages">
          {messages[currentChannel].map((m, idx) => {

            return (
<div
  key={m.id || idx}
  className="message-container message-left" // tous alignés à gauche
>
  <div className="message-bubble">
    {/* Avatar toujours affiché */}
    <img src={m.avatar} className="msg-avatar" />

    <div className="msg-content">
      <div className="msg-header">
        <span className="msg-username">{m.username}</span>
        <span className="msg-time">
          {new Date(m.created_at).toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          })}
        </span>
      </div>

      <div className="msg-text">{m.text}</div>
    </div>
  </div>
</div>
            );
          })}

          <div ref={messagesEndRef}></div>
        </div>

        <div className="input-area">
          <input
            type="text"
            placeholder={`Message #${currentChannel}…`}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
          />
          <button onClick={sendMessage}>Envoyer</button>
        </div>
      </div>

      {/* AMIS */}
      <div className="friends-list">
        <h2>Amis connectés</h2>

        {friends
          .filter((f) => f.username !== username)
          .map((f, i) => (
            <div key={i} className="friend">
              <div className="friend-avatar-wrapper">
                <img src={f.avatar} />
                <span className="friend-status"></span>
              </div>
              <span className="friend-name">{f.username}</span>
            </div>
          ))}
      </div>
    </div>
  );
}
