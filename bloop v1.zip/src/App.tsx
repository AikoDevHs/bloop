import { useState, useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import './App.css';

const socket = io(`${window.location.protocol}//${window.location.hostname}:3001`);

const CHANNELS = ['général', 'discussion', 'projets'];

// Génère un avatar random
const randomAvatar = () =>
  `https://api.dicebear.com/7.x/thumbs/svg?seed=${Math.random()}`;

function App() {
  // --- Login local ---
  const [username] = useState("User" + Math.floor(Math.random() * 999));
  const [avatar] = useState(randomAvatar());

  // --- Chat state ---
  const [currentChannel, setCurrentChannel] = useState('général');
  const [messages, setMessages] = useState<Record<string, any[]>>({
    général: [],
    discussion: [],
    projets: []
  });
  const [input, setInput] = useState('');

  // --- Liste d'amis connectés ---
  const [friends, setFriends] = useState<any[]>([]);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  useEffect(scrollToBottom, [messages[currentChannel]]);

  // --- Connexion socket ---
  useEffect(() => {
    socket.emit("user_connected", { username, avatar });

    socket.on("update_users", (users) => {
      setFriends(users);
    });

    socket.emit("join_channel", currentChannel);

    socket.on("receive_message", ({ channel, message }) => {
      setMessages(prev => ({
        ...prev,
        [channel]: [...prev[channel], message]
      }));
    });

    return () => {
      socket.off("receive_message");
      socket.off("update_users");
    };
  }, [currentChannel, username, avatar]);

  const sendMessage = () => {
    if (!input.trim()) return;

    socket.emit("send_message", {
      channel: currentChannel,
      message: {
        from: username,
        avatar,
        text: input
      }
    });

    setInput('');
  };

  return (
    <div className="discord-app">

      {/* --- Colonne gauche : LOGIN + CHANNELS --- */}
      <div className="sidebar">

        <div className="user-profile">
          <img src={avatar} alt="avatar" />
          <h3>{username}</h3>
        </div>

        <ul>
          {CHANNELS.map((ch) => (
            <li
              key={ch}
              onClick={() =>
                setCurrentChannel(ch)
              }
              style={{
                background: currentChannel === ch ? '#5865F2' : 'transparent',
                borderRadius: '5px',
                padding: '5px'
              }}
            >
              # {ch}
            </li>
          ))}
        </ul>
      </div>

      {/* --- Colonne centre Messages --- */}
      <div className="chat-area">

        <div className="messages">
          {messages[currentChannel].map((m, idx) => {
            const mine = m.from === username;

            return (
              <div
                key={idx}
                className={
                  "message-container " +
                  (mine ? "message-right" : "message-left")
                }
              >
                <div className="message-bubble">
                  {!mine && <img src={m.avatar} alt="" />}
                  <div>
                    {!mine && <span className="username">{m.from}: </span>}
                    <span>{m.text}</span>
                  </div>
                  {mine && <img src={m.avatar} alt="" />}
                </div>
              </div>
            );
          })}

          <div ref={messagesEndRef}></div>
        </div>

        <div className="input-area">
          <input
            type="text"
            placeholder={`Message #${currentChannel}…`}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && sendMessage()}
          />
          <button onClick={sendMessage}>Envoyer</button>
        </div>
      </div>

      {/* --- Colonne de droite : AMIS ACTIFS --- */}
      <div className="friends-list">
        <h2>Amis connectés</h2>

        {friends.map((f, i) => (
          <div key={i} className="friend">
            <img src={f.avatar} alt="" />
            <span>{f.username}</span>
          </div>
        ))}

      </div>

    </div>
  );
}

export default App;
